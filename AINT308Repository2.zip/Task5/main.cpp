//James Rogers Nov 2020 (c) Plymouth University
#include "main.h"
#include "faceclassifier.h"

int main()
{

    //===========================Load Face Recognition Networks===========================
    String ClassNetPath = "C:/AINT308Lib/Data/Classifier Models/dlib_face_recognition_resnet_model_v1.dat";
    String GenderNetPath = "C:/AINT308Lib/Data/Classifier Models/dnn_gender_classifier_v1.dat";
    String AgeNetPath = "C:/AINT308Lib/Data/Classifier Models/dnn_age_predictor_v1.dat";

    FaceClassifier Classifier(ClassNetPath,GenderNetPath,AgeNetPath);

    //==============================Load Face Detector Model==============================
    String FaceDetectorPath = "C:/AINT308Lib/Data/Classifier Models/haarcascade_frontalface_default.xml";
    CascadeClassifier face_cascade;

    if(!face_cascade.load(FaceDetectorPath)){
            cout << "Error loading face cascade\n";
            return -1;
    }

    //===============================Find Profile Embeddings==============================
    Mat Profile = imread("C:/AINT308Lib/Data/Task5 Images/Profile.png"); //Load profile image

    //create a grey version of the profile picture
    Mat ProfileGray;
    cvtColor(Profile, ProfileGray, COLOR_BGR2GRAY);

    //find faces in the profile picture
    vector<Rect> ProfileFaces;
    face_cascade.detectMultiScale(ProfileGray, ProfileFaces);

    //if no faces are found, there has been an error in the facial detection
    if(ProfileFaces.size()==0){
        cout<<"No faces found in profile"<<endl;
        return -1;
    }

    //if a face/faces have been found, assume face[0] is the target and create a cropped image of it
    Mat ProfileFaceImg;
    Profile(ProfileFaces[0]).copyTo(ProfileFaceImg);

    //use the classifier class to extract facial embeddings
    dlib::matrix<float,0,1> ProfileEmbedding = Classifier.FaceEmbeddings(ProfileFaceImg);

    //draw a box around the target face
    rectangle(Profile, ProfileFaces[0], Scalar(0,255,0),2);

    //display the profile picture with the detected face untill x is pressed.
    //while(waitKey(10)!='x'){
    //    imshow("Profile", Profile);
    //}

    //================================Your code goes here=============================
    int nr=0,i;

    //loop over images provided
    for(;nr<=4;nr++)
    {
        cout<<"_____________________________________________"<<endl;
        dlib::matrix<float,0,1> facesEmbeded[20];

        //read image
        Mat peeps=imread("C:/AINT308Lib/Data/Task5 Images/" + to_string(nr) + ".png");
        cout<<"image "<<nr<<" has been opened"<<endl;

        //create a grey version of the  picture
        Mat peepsGray;
        cvtColor(peeps, peepsGray, COLOR_BGR2GRAY);

        //find faces in the profile picture
        vector<Rect> peepsFaces;
        face_cascade.detectMultiScale(peepsGray, peepsFaces,1.1,12,0,Size(50,50),Size(200,200));


        cout<<endl<<"faces found:"<<peepsFaces.size()<<endl;
        //if no faces are found, there has been an error in the facial detection
        if(peepsFaces.size()==0){
            cout<<"No faces found in group photo"<<endl;
        }

        //loop over Faces found
        for(i=0;i<(int)peepsFaces.size();i++)
        {
            //if faces have been found, face[i] is the target and create a cropped image of it
            Mat picFaceImg;
            peeps(peepsFaces[i]).copyTo(picFaceImg);

            //use the classifier class to extract facial embeddings
            facesEmbeded[i] = Classifier.FaceEmbeddings(picFaceImg);

            //compare to profile
            if(dlib::length(ProfileEmbedding-facesEmbeded[i])<0.5)
                rectangle(peeps, peepsFaces[i], Scalar(0,0,255),5);
            else //draw a box around the target face
                rectangle(peeps, peepsFaces[i], Scalar(0,255,0),2);
        }
        //showcase the photos
        while(waitKey(10)!='x'){
            imshow("Profile", Profile);
            imshow("group", peeps);
        }

    }//for end

}
















